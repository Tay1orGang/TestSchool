package market;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class TestClass {

    private WebDriver driver;

    @BeforeTest
    public void beforeTest() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Test
    public void test() throws Throwable {
        driver.get("https://market.yandex.ru/");
        driver.findElement(By.xpath("//input[@class='input__control']")).sendKeys("samsung galaxy");
        driver.findElement(By.xpath("//span[@class='search2__button']")).click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='filter-applied-results metrika i-bem filter-applied-results_js_inited']")));
        List<WebElement> model = driver.findElements(By.xpath("//a[@class='snippet-card__header-link shop-history__link link i-bem link_js_inited']"));
        List<String> genres = new ArrayList<String>();
        for (WebElement element2 : model) {
            genres.add(element2.getText());

        }
        System.out.println(genres.toString().contains("Samsung Galaxy") + "");

        List<WebElement> price = driver.findElements(By.xpath("//div[@class='price']"));
        List<String> priceList = new ArrayList<String>();
        for (WebElement element1 : price) {
            priceList.add(element1.getText());
        }
        System.out.println(genres.toString() + priceList.toString());
        WebElement find = driver.findElement(By.xpath("//a[text()='по цене']"));
        find.click();
        WebDriverWait wait1 = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='layout__col layout__col_search-results_normal i-bem']")));
        Thread.sleep(1500);
        driver.findElement(By.xpath("//a[@class='snippet-card__header-link shop-history__link link i-bem link_js_inited']")).click();
        WebElement shop = driver.findElement(By.xpath("//span[@class='n-shop-name i-bem n-shop-name_js_inited']"));
        WebElement price1 = driver.findElement(By.xpath("//span[@class='price']"));
        System.out.println(shop.getText());
        System.out.println(price1.getText());

    }



    @AfterTest
    public void afterTest() {
        driver.quit();
    }
}
